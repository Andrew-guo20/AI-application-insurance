-- --------------------------------------------------------
-- 主机:                           192.168.150.101
-- 服务器版本:                        8.0.30 - MySQL Community Server - GPL
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  12.17.0.7270
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 导出 robot 的数据库结构
CREATE DATABASE IF NOT EXISTS `robot` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `robot`;

-- 导出  表 robot.conversations 结构
CREATE TABLE IF NOT EXISTS `conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `title` varchar(100) DEFAULT 'New Chat',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `conversations_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 正在导出表  robot.conversations 的数据：~2 rows (大约)
DELETE FROM `conversations`;
INSERT INTO `conversations` (`id`, `user_id`, `title`, `created_at`, `updated_at`) VALUES
	(1, 1, 'hi', '2026-07-06 18:16:57', '2026-07-06 18:16:59'),
	(2, 1, '你好', '2026-07-06 18:19:42', '2026-07-06 18:19:44');

-- 导出  表 robot.messages 结构
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversation_id` int NOT NULL,
  `role` enum('user','assistant') NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `conversation_id` (`conversation_id`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 正在导出表  robot.messages 的数据：~6 rows (大约)
DELETE FROM `messages`;
INSERT INTO `messages` (`id`, `conversation_id`, `role`, `content`, `created_at`) VALUES
	(1, 1, 'user', 'hi', '2026-07-06 18:16:59'),
	(2, 1, 'assistant', 'Hi there! 👋 很高兴见到你！有什么我可以帮你的吗？无论是聊天、解答问题，还是其他方面的帮助，我都很乐意陪你聊聊！😊', '2026-07-06 18:17:01'),
	(3, 1, 'user', '帮我写Python的HelloWorld', '2026-07-06 18:19:35'),
	(4, 1, 'assistant', '当然！这是一个最简单的 Python Hello World 程序：\n\n```python\nprint("Hello, World!")\n```\n\n### 运行方法：\n1. 将上面这行代码保存为 `hello.py` 文件。\n2. 在终端或命令行中运行：`python hello.py`（或 `python3 hello.py`）\n3. 你会看到输出：`Hello, World!`\n\n如果你想在交互式环境中直接测试，可以在 Python 解释器中输入：\n```python\nprint("Hello, World!")\n```\n然后按回车即可看到结果。\n\n祝你编程愉快！😊', '2026-07-06 18:19:38'),
	(5, 2, 'user', '你好', '2026-07-06 18:19:44'),
	(6, 2, 'assistant', '你好！很高兴见到你！😊\n\n我是DeepSeek，随时准备为你提供各种帮助——无论是回答问题、创作内容、分析数据，还是陪你聊天解闷。有什么可以帮你的吗？尽管说，我会全力以赴！', '2026-07-06 18:19:47');

-- 导出  表 robot.users 结构
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- 正在导出表  robot.users 的数据：~0 rows (大约)
DELETE FROM `users`;
INSERT INTO `users` (`id`, `username`, `password`, `created_at`) VALUES
	(1, 'huge', '$2b$12$5sGYlLBCsqv8GNcGd14WjuAje9Rs.nehIfIF3n4PtITvrLpXABsZC', '2026-07-06 18:16:50');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
